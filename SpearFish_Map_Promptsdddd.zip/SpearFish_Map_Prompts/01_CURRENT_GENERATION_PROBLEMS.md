# CURRENT GENERATION PROBLEMS (read with the style bible)

The current maps come from the generator in `Bdokkx/shittyclaude` > `roblox-island/` (branch `claude/jolly-bardeen-kv6g11`). Photos of every map are in `references/current_generation/`. This file lists exactly what is wrong in them so it does not happen again.

| Real map name | Theme | Origin in Studio | Map prompt |
|---|---|---|---|
| **VoxelIsland** | Grass (starter) | 0, 0, 0 | `maps/01_VoxelIsland_GRASS.md` |
| **DesertCoast** | Desert | 1300, 0, 0 | `maps/02_DesertCoast_DESERT.md` |
| **FrostCoast** | Snow | 2600, 0, 0 | `maps/03_FrostCoast_SNOW.md` |
| **VolcanicIsland** | Volcano | 3900, 0, 0 | `maps/04_VolcanicIsland_VOLCANO.md` |
| **CoralReef** | Underwater reef | 0, 0, 900 | see section 6 below |

Keep these names and origins so existing scripts (LightingAndWater.lua, MeshSwap.lua, teleports) still work.

---

## 1. Problems on EVERY map (from `00_ALL/AllIslands.jpg`)

1. **Clutter everywhere.** About 32,000 to 35,000 parts per island, and the README admits it is "mostly clutter". Tufts, small rocks, flowers, and bushes are sprinkled evenly over every walkable tile. There is no clean ground anywhere.
2. **Checkerboard color noise.** Every ground tile and cliff block picks a random shade, so grass, sand, cobble, snow and ash all look like static. The target reef uses calm, solid colors.
3. **Stair-stepped voxel terrain.** Cliffs are stacks of 1-block steps with random tones instead of big angled slabs with clean horizontal bands.
4. **Two styles fighting.** Clean blocky parts sit next to lumpy, triangulated "deformed mesh" rocks (cliff walls, crags, boulders). They do not match each other or the target. The target uses crisp, chunky slab shapes with the stud texture, not noisy faceted blobs.
5. **Too many trees in an even carpet.** Trees fill every gap, which hides the layout and the paths.
6. **Weak buildings.** Houses are plain boxes with black-square windows (see every `_assets.jpg`). No trim, no inset frames, no roof overhang, no entrance props, no signs.
7. **No gameplay layout.** There is no Fish Market, Spear Shop, Upgrade Station, or Travel Boat. The dock is a generic T-pier with no spearfishing setup and no reef visible under it.
8. **Spiral paths.** Every island uses the same spiral staircase up a mountain. It reads as generated, not designed.
9. **Small props at the wrong scale.** Torches, wells, stalls and pots are tiny compared to the player.

---

## 2. VoxelIsland (Grass) problems
Photos: `current_generation/VoxelIsland/` and `references/02_CURRENT_grass_island_overview.png`

- Grass tops are a noisy mix of 4 greens plus moss; cliffs mix periwinkle, gray, dark and moss blocks at random.
- Cobblestone plaza is a random 5-tone checkerboard; the plaza does not read as one place.
- Sea stacks and cliff rocks are lumpy mesh blobs covered in green moss noise.
- Small gray rocks scattered across the beach for no reason.
- The village is 1 stall, a few benches and a campfire. Nothing a player can use.
- The summit lookout is a tiny stone stub; not a real landmark.
- **Keep:** the periwinkle + green + yellow sand-band color idea, the stone arch idea, the T-dock position, the pine trees (just fewer and clumped).

## 3. DesertCoast (Desert) problems
Photos: `current_generation/DesertCoast/` and `references/03`, `04`, `05`

- Worst clutter of all four: hundreds of small red/tan/green blocks on every sand surface.
- Sand floor is a random 3-tone checkerboard; the plateau tops look dirty.
- Red rock is noisy (red, dark red, light red, terracotta at random) instead of clean strata bands.
- Beach "desert rocks" are lumpy mesh blobs dotted randomly around the shore.
- Adobe houses are boxes with black holes and a blue table stuck to the front (`DesertCoast_assets.jpg`).
- Palm trees are noisy voxel smears; too many of them, evenly spread.
- Stud texture scale differs between the village floor (big studs) and the cliffs (tiny studs).
- The ziggurat landmark is small and plain; the waterfall is a thin blue strip.
- **Keep:** the oasis lake, the mesa ring around the edge, the ziggurat/temple idea, the striped market stalls, the long pier.

## 4. FrostCoast (Snow) problems
Photos: `current_generation/FrostCoast/`

- Almost everything is the same white/pale blue, so nothing stands out. No warm contrast.
- Cliffs are noisy stacks of white, pale blue and ice blocks; it reads as a blur.
- Plaza is a random gray/blue checkerboard.
- Log cabins are plain boxes with a striped roof and two glowing squares. All four are nearly identical.
- Way too many snow pines, evenly carpeted over every slope.
- Ice crystals and icebergs are lumpy mesh blobs.
- The summit "flag lookout" is a thin pole, not a landmark.
- **Keep:** the log cabin + campfire + snowman village idea, the frozen pond, the frozen waterfall, icebergs offshore (fewer, bigger, cleaner).

## 5. VolcanicIsland (Volcano) problems
Photos: `current_generation/VolcanicIsland/`

- Colors are muddy brown and gray. Nothing ties it to the reef's periwinkle family. No cool accent to balance the orange.
- Ground is a random mix of gray, dark gray, brown and red blocks; very noisy and dark.
- Lava rivers are thin yellow zigzags that look like lines painted on the ground, not flowing lava with crust edges.
- Basalt columns and obsidian shards are scattered everywhere as small spikes.
- The volcano is not a readable cone; from the overview it is a lumpy hill. There is no clear crater landmark.
- Pine trees on a volcano island break the theme.
- Stilt huts are all the same tiny box with a red roof.
- **Keep:** the lava pool crater idea, lava falls, basalt columns (as 2 to 3 hero clusters), braziers, the stilt-hut village idea (but varied and bigger).

## 6. CoralReef (generated) problems
Photo: `current_generation/CoralReef/CoralReef_GENERATED_not_target.jpg`

This is **NOT** the target. The target is `references/01_STYLE_TARGET_coral_reef.png`. Differences:
- Generated: corals are spaced evenly in a grid-like spread across flat sand. Target: corals are grouped on ledges and rock bases with open sand between.
- Generated: rocks are small, separate lumps. Target: big stacked, tilted shelves that form a connected reef wall with overhangs.
- Generated: kelp is everywhere. Target: kelp is used in a few tall clumps.
- Generated: coral pieces are thin pixel sticks. Target: corals are chunkier tubes and fans with a clear brown base.
- Use the target style for the shallow reef ring around every island.

---

## 7. Root causes in the generator (for whoever edits `roblox-island/gen/`)

If the maps are regenerated with code instead of rebuilt by hand, fix these first:

| Cause | File | Fix |
|---|---|---|
| Clutter is a per-tile random chance (for example `GrassTuft 0.13`, `Fern 0.05`, `SmallRock 0.02`) on every walkable tile, plus `beach_clutter` and `path_clutter` lists | `gen/themes.py`, `gen/island.py` | Remove per-tile clutter. Place props as **clusters of 3 to 5** at chosen anchor points only (cliff feet, building walls, path edges, dock posts), with a minimum spacing between clusters. Delete `SmallRock` / `*Rock` from beach and path clutter entirely. Target **under 12,000 parts per island**. |
| Every tile picks a weighted random color (for example `top=[grass 6, grass_dark 2.5, grass_light 2, moss 0.6]`, `rock` has 7 shades) | `gen/themes.py`, `gen/island.py` | Use ONE base color per surface. Add variation with **low-frequency noise patches** (8x8 studs or bigger) of at most 2 extra tones. Cliff color comes from **height bands** (light top, mid, dark base), never per-block random. Remove `rock_gray` and `moss` from rock lists. |
| Cobble/plaza uses 5 random tones | `gen/island.py` (cobble) | Use 2 tones in a regular pattern or one solid tone with a border. |
| Cliffs are 1-block height steps | `gen/island.py` | Build cliffs from large slabs (4 to 16 studs wide, 2 to 6 thick) with slight tilt and 1 to 3 stud overhang lips. |
| Deformed mesh rocks (voxel remesh + noise + decimate) look lumpy and do not match the parts | `tools/blender_meshes.py`, `roblox/MeshSwap.lua` | Drop the noisy deformation. Rocks should be chunky angled slabs like the target reef. Keep meshes only for reusing shapes, not for adding noise. |
| `tree_density` 1.0 to 1.15 fills every gap | `gen/themes.py` | Lower density and place trees in clumps of 3 to 7 with clear gaps. Keep paths and the plaza free of trees. |
| Same spiral path layout on every island | `gen/island.py` | Use the shared layout in style bible section 4 (dock > plaza > shops > upgrade station > landmark). |
| Building assets are plain boxes | `gen/assets.py`, `gen/theme_assets.py` | Rebuild buildings to the Building Quality Standard (style bible section 6). |
| Stud texture scale differs between parts and meshes | `tools/blender_meshes.py` UVs, MaterialVariant | One stud texture, one world scale everywhere (style bible section 7). |
