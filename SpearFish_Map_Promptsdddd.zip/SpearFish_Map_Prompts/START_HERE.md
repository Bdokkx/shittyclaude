# START HERE (instructions for Claude)

You've been sent this folder so you can build the maps for my Roblox spearfishing game.

1. Read `MASTER_PROMPT.md` all the way through. It has every rule, all 4 maps, and the list of problems to fix.
2. Look at every image in `references/`. `references/01_STYLE_TARGET_coral_reef.png` is the look to match. The rest show the current maps and what NOT to do.
3. Build the maps in this order: VoxelIsland (grass), DesertCoast (desert), FrostCoast (snow), VolcanicIsland (volcano).
   - If you are connected to Roblox Studio, build directly in Studio and screenshot each stage.
   - If you are not connected, write one standalone Luau builder script per island (for example `VoxelIslandBuilder.server.lua`) that I can run in Studio to build it.
4. Before finishing each island, run the self-review checklist (style bible section 8) and fix anything that fails.
