# Spearfishing Islands: Map Prompt Pack

Prompt pack for rebuilding all 4 islands (VoxelIsland, DesertCoast, FrostCoast, VolcanicIsland) plus the reef ring, in a clean, high-quality stud style that matches the coral reef reference.

## What's inside

| File | What it is |
|---|---|
| `MASTER_PROMPT.md` | **Everything in one file.** Paste this if you want one AI session to do all 4 maps. |
| `00_STYLE_BIBLE.md` | Shared rules: style, anti-clutter rules, building quality, gameplay layout, tech setup, self-check list. |
| `01_CURRENT_GENERATION_PROBLEMS.md` | Every problem in the current generated maps, per map, plus the root causes in the generator code. |
| `maps/01_VoxelIsland_GRASS.md` | Grass island (starter). |
| `maps/02_DesertCoast_DESERT.md` | Desert island. |
| `maps/03_FrostCoast_SNOW.md` | Snow island. |
| `maps/04_VolcanicIsland_VOLCANO.md` | Volcano island. |
| `references/01_STYLE_TARGET_coral_reef.png` | **The target look.** Everything should match this. |
| `references/02-05_CURRENT_*.png` | Your Studio screenshots of the current grass and desert islands. |
| `references/current_generation/<Map>/` | Overview posters, village, cliff and asset shots of every current map from the repo (what NOT to do). |
| `references/current_generation/CoralReef/` | The generated reef. Low quality, NOT the target. |

## How to use

**Option A: one map at a time (recommended, better results)**
1. Start a new AI chat or session with Studio access.
2. Attach `references/01_STYLE_TARGET_coral_reef.png` plus that map's folder in `references/current_generation/`.
3. Paste `00_STYLE_BIBLE.md`, then `01_CURRENT_GENERATION_PROBLEMS.md`, then ONE map file.
4. Add: "Start with the terrain and dock, send me screenshots before doing buildings."
5. Repeat in a fresh session for each island.

**Option B: all at once**
Attach the images and paste `MASTER_PROMPT.md`.

**Option C: fixing the generator code**
Point the AI at the `roblox-island/` repo and paste `MASTER_PROMPT.md`. Section 7 of the problems file lists the exact code causes.

**Option D: hiring a builder**
Send the whole folder. The style bible works as a commission brief.

## Tips
- Do VoxelIsland first and approve it. Then tell the AI to match that quality on the other three.
- Ask for screenshots after each stage: terrain, dock and reef, buildings, props, lighting.
- If something comes back cluttered, reply: "Run the self-review checklist in section 8 of the style bible and fix everything that fails."
