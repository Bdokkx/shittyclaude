# STYLE BIBLE: Spearfishing Islands (Roblox, Stud Style)

Paste this whole file into the AI (or send it to your builder) BEFORE any map prompt, together with `01_CURRENT_GENERATION_PROBLEMS.md`. Every map must follow these rules. Attach the images in `/references` (including `references/current_generation/`) with it.

---

## 1. You are building

A Roblox spearfishing game in a chunky, toy-like **stud style**. The player stands on a dock, shoots fish in the water with a speargun, sells fish at the market, buys better spearguns, upgrades their island, then travels to the next island and repeats.

Island progression (level gated), using the real map names:
**VoxelIsland (Grass, start) > DesertCoast (Desert) > FrostCoast (Snow) > VolcanicIsland (Volcano).** Plus the **CoralReef** underwater map. Keep these Model names and their Studio origins (0,0,0 / 1300,0,0 / 2600,0,0 / 3900,0,0 / reef at 0,0,900).

Your job: build or rebuild each island so it looks intentional, high quality, and matches **`references/01_STYLE_TARGET_coral_reef.png`**. That image is the target. The other reference images show the CURRENT maps and what is wrong with them. `references/current_generation/` has overview, village, cliff and asset shots of every current map; `01_CURRENT_GENERATION_PROBLEMS.md` lists every problem in them. Note: `current_generation/CoralReef/CoralReef_GENERATED_not_target.jpg` is the low-quality generated reef, NOT the target.

---

## 2. What the target image does right (copy this)

Study `01_STYLE_TARGET_coral_reef.png` and match these qualities:

1. **Big, chunky forms.** Rock is built from large stacked slabs and shelves (4 to 16 studs wide, 2 to 6 studs thick), not hundreds of 1x1 cubes.
2. **Angled layering.** Slabs are tilted 5 to 20 degrees and offset from each other so they overhang like shelves. Nothing is a perfect staircase of cubes.
3. **One consistent stud texture.** Every surface has the same inset-square stud pattern at the SAME world scale. A stud on a cliff is the same size as a stud on a crate.
4. **Limited palette.** One dominant base color (periwinkle rock), one secondary (butter sand), and a set of bright accents used only on props (corals). Each material reads as one clear color with gentle tone variation.
5. **Props are grouped on purpose.** Corals come in clusters of 2 to 4 tubes on a shared base. Clusters sit on ledges, at the base of rocks, or along edges. Nothing floats randomly in open ground.
6. **Clean negative space.** Large areas of floor are left open and calm so the props and rock forms stand out.
7. **Readable silhouettes.** You can tell what every object is from far away.

---

## 3. What is wrong with the current maps (fix this)

See references 02 to 05 and everything in `references/current_generation/`. Full per-map list in `01_CURRENT_GENERATION_PROBLEMS.md`.

| Problem | Where you can see it | Fix |
|---|---|---|
| Hundreds of loose 1x1 and 2x1 bricks scattered on sand and grass | 03, 04 (beach, plateaus) | Delete them. Props only appear in deliberate clusters (rule 5.2). |
| Ground is a noisy checkerboard of random tones | 02 (grass), 05 (village floor) | Use 2 to 3 tones in large organic patches, 8x8 studs or bigger. |
| Cliffs are stair-stepped voxel cubes with per-block color noise | 02, 03 | Rebuild as large angled slabs and shelves with 2 to 3 horizontal color bands. |
| Buildings are plain boxes with a hole for a window | 05 | Follow the Building Quality Standard (section 6). |
| Stud texture scale is inconsistent (huge studs on some parts, tiny on others) | 05 | One MaterialVariant, fixed StudsPerTile (section 7). |
| Random rock lumps dotted around the beach | 03, 04 | Replace with 2 to 4 hero rock formations placed with purpose. |
| Props too small for the player (lamps, tables, well) | 05 | Scale to the player (section 5.4). |
| Palms/trees look like noisy voxel smears | 03, 04 | Build clean stylized trees with 3 to 5 big leaf shapes (section 6.4). |
| No clear focal point or path; eye has nowhere to go | 02, 03 | Dock > plaza > shops > landmark path (section 4). |
| Lumpy, triangulated "deformed mesh" rocks next to clean blocks (two styles fighting) | current_generation `_cliffs`, `_assets` | Use crisp chunky slab rocks like the target. No noisy faceted blobs. |
| Trees carpeted evenly over every slope | current_generation `_poster` | Clumps of 3 to 7 with clear gaps; paths and plaza stay clear. |
| Same spiral staircase mountain on every island | current_generation `_poster` top views | Use the shared gameplay layout (section 4). |
| 32k to 35k parts per island, mostly clutter | repo README | Under 12,000 parts per island. |

---

## 4. Island layout (same for every island)

Every island uses the same gameplay layout so players learn it once.

```
          [ LANDMARK ]        <- tallest point, visible from the dock
               |
      [ UPGRADE STATION ]     <- island upgrade hut / builder yard
           /       \
 [ FISH MARKET ]  [ SPEAR SHOP ]
           \       /
         [ HUB PLAZA ]        <- spawn, open, clean floor
               |
          main path (6-8 studs wide)
               |
         [ MAIN DOCK ]  ->  spearfishing water + shallow reef ring
               |
        [ TRAVEL BOAT ]       <- go to next island (locked until level)
```

**Required zones per island:**

1. **Main Dock (spearfishing spot).** Wide platform (at least 24x16 studs at the end) so many players can shoot at once. Railings with gaps to shoot through, spear racks, bait buckets, lanterns on posts, rope coils. The water below must look rich: a shallow reef shelf in the coral reef style, visible through clear water, so players WANT to shoot there.
2. **Hub Plaza.** Spawn point. Open, readable, clean floor with one centerpiece (statue, well, fountain, totem). Shops face the plaza.
3. **Fish Market (sell).** Stall or building with a big readable sign, ice boxes, hanging fish, scale/weighing station, crates.
4. **Spear Shop (buy spearguns).** Spears displayed on wall racks and a counter, target dummy or practice board, signage.
5. **Island Upgrade Station.** Builder hut or workshop with scaffolding, lumber piles, a blueprint board.
6. **Landmark.** One tall hero structure per island, visible from the dock (lighthouse, temple, ice spire, volcano peak).
7. **Travel Boat / Dock 2.** Boat or second pier that teleports to the next island.
8. **Shallow Reef Ring.** Underwater shelf around the island in the coral reef style, themed to the biome (section 8 in each map file).

**Island Upgrade Tiers.** Build each island so it visibly improves when the player upgrades. Make 3 tiers as separate Models (`Tier1`, `Tier2`, `Tier3`) that a script can toggle:
- Tier 1: small, humble. Short dock, simple stalls, few decorations.
- Tier 2: dock extended, stalls become buildings, more lanterns and flags.
- Tier 3: big dock with a second platform, fully decorated buildings, landmark lit up, extra hero props.

---

## 5. Composition rules (the anti-clutter rules)

### 5.1 Density
- Leave **at least 40% of walkable ground** as clean open floor.
- Detail goes where players look: around the dock, the plaza, building entrances, and along path edges. Far corners stay simple.

### 5.2 Clusters, not scatter
- **No loose single parts.** Delete any part smaller than 2x2 studs that is not part of a building or cluster.
- Props come in **clusters of 3 to 5** objects of varying size (1 large, 1 to 2 medium, 1 to 2 small).
- Every cluster is **anchored to something**: a wall base, a rock, a path edge, a dock post. Never in the middle of open ground.
- Rocks: use **2 to 4 hero rock formations** per beach, not 30 small rocks.

### 5.3 Color
- **60 / 30 / 10 rule.** 60% dominant base, 30% secondary, 10% bright accents.
- Bright accents go ONLY on props, signs, awnings, flowers, corals, lanterns. Never on terrain.
- Terrain gets tone variation in **large patches** and **horizontal bands** on cliffs (2 to 3 bands: light top, mid, dark base). No per-block random tones.

### 5.4 Scale (player is about 5 studs tall)
- Door: 4 wide, 7 to 8 tall.
- One-story building: 10 to 14 studs tall to roof peak.
- Lamp post: 8 to 10 studs.
- Market stall counter: 3.5 studs tall.
- Paths: 6 to 8 studs wide. Plaza: 30x30 studs minimum.
- Trees: 14 to 25 studs tall.

### 5.5 Forms
- Terrain is built in **3 height tiers**: beach level, main island level, high ground with landmark. Connect them with wide, clear stairs or ramps.
- Cliffs: stack big slabs with overhanging lips (1 to 3 studs) and slight tilts, like the reef shelves.
- Shorelines: clean beach terraces that step down into the water in 2 to 3 wide shelves, then the reef ring.
- Avoid perfect symmetry and perfect straight lines on natural forms. Man-made things (dock, buildings) can be straight but may lean slightly for charm.

### 5.6 Readability
- From the dock, a new player must see: the plaza, at least two shops, and the landmark.
- Paths lead the eye: dock > plaza > shops > landmark.
- Use lanterns or torches along the main path as guides.

---

## 6. Building Quality Standard

Every building and structure must have **3 layers of detail**:

1. **Primary form.** Interesting shape, not a box. Use L-shapes, offset second floors, tapered walls, slightly leaning walls, stepped roofs.
2. **Secondary details.** Foundation plinth (1 to 2 studs, darker tone). Corner pillars or edge trim in a contrasting tone. Windows recessed 0.5 to 1 stud with frames and sills. Roof overhangs 1 to 2 studs with a fascia/edge band. Door frame and step.
3. **Tertiary props.** A prop cluster at the entrance (crates, barrels, sign, lantern, plant pot). Awnings, banners, hanging signs, chimneys.

**Rules:**
- No flat wall area bigger than 10x10 studs without a break (window, trim, beam, color band).
- Every shop has a **big readable sign** with an icon (fish, spear, hammer).
- Roofs are a different color from walls.
- Wood: show planks with 2 alternating tones, visible posts and beams.

### 6.4 Trees and plants
- Trees: thick trunk built from 2 to 4 angled segments, canopy made from 3 to 5 large leaf shapes or tiers. No noisy voxel leaves.
- Use 3 sizes of each tree type and rotate them so they don't look copy-pasted.
- Group trees in clumps of 3 to 7 with gaps between clumps. Not an even carpet.
- Plants and flowers: clusters at rock bases and path edges, like the corals in the target.

---

## 7. Technical setup (Roblox Studio)

### Stud texture
- Create ONE `MaterialVariant` named `StudInset` (inset-square stud pattern like the target image) under `MaterialService`, based on `Plastic`.
- Set `StudsPerTile` so that **one stud on the texture = one stud in the world** (usually `StudsPerTile = 1` for a single-stud tile, or match the tile size of your texture).
- Use `TexturePack` / MaterialVariant only. Do NOT use Decals or Textures per part for studs (causes scale mismatch).
- Optional: a second variant `StudFlat` (smaller, subtle) for water-adjacent sand and paths.

### Grid
- Move snap: 1 stud (0.5 for small details). Rotation snap: 15 degrees for terrain slabs, 5 for fine tuning.
- Part sizes are whole studs or half studs.

### Performance
- All parts `Anchored = true`.
- Decorative parts: `CanCollide = false`, `CanTouch = false`, `CanQuery = false` where possible.
- Small props: `CastShadow = false`.
- Repeated props (trees, crates, lanterns, corals, rocks) are **Packages or MeshParts** so they are reused, not rebuilt.
- `Workspace.StreamingEnabled = true`.
- Budget: aim for under **12,000 parts per island** (use bigger slabs instead of many small blocks; this also fixes the clutter look).
- Organize: `Workspace/Islands/<IslandName>/{Terrain, Buildings, Props, Dock, Reef, Lighting, Tier1, Tier2, Tier3, Spawns}`.

### Lighting (base, adjust per biome in map files)
- `Lighting.Technology = Future` (or `ShadowMap` for low-end).
- `Brightness = 2.5`, `EnvironmentDiffuseScale = 0.5`, `EnvironmentSpecularScale = 0.3`.
- `ColorCorrectionEffect`: Saturation 0.15, Contrast 0.05.
- `Atmosphere`: Density 0.25, Haze 1, Glare 0 (tint per biome).
- `BloomEffect`: Intensity 0.4, Size 24, Threshold 1.5 (for lanterns and lava).
- Each island has a lighting preset folder that a script applies on teleport.

### Water
- Clear, saturated blue water. If using Terrain water: `WaterTransparency = 0.6` or higher so the reef ring is visible from the dock, `WaterReflectance = 0.1`, `WaterWaveSize = 0.1`.
- Water color tinted per biome.

---

## 8. Self-review checklist (do this before saying you are done)

Take screenshots from: (a) the end of the dock looking at the island, (b) overhead at 45 degrees like reference 02, (c) the plaza at player height. Compare each against `01_STYLE_TARGET_coral_reef.png`.

- [ ] Same stud size on every surface.
- [ ] No loose single bricks anywhere. Searched and deleted parts under 2x2 that are not in a cluster.
- [ ] At least 40% clean open ground.
- [ ] Cliffs are big angled slabs with color bands, not stair-stepped cubes.
- [ ] Every building has foundation, trim, recessed windows, overhanging roof, entrance prop cluster, sign.
- [ ] Dock is wide, decorated, and has a visible reef below.
- [ ] Landmark is visible from the dock.
- [ ] Palette follows 60 / 30 / 10 with accents only on props.
- [ ] Tier1, Tier2, Tier3 models exist and toggle cleanly.
- [ ] Part count under budget, decor has collisions off.

If any box fails, fix it and re-check.
