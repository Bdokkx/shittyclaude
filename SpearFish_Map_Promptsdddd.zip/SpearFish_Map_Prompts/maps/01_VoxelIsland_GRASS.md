# MAP 1: VoxelIsland (GRASS, starter island, origin 0,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **VoxelIsland** (see `references/02_CURRENT_grass_island_overview.png` and `references/current_generation/VoxelIsland/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 2). Keep the Model name `VoxelIsland`. Keep the general layout idea (dock bottom left, plaza in the middle, tower on the hill, stone arch top left) but rebuild every surface to the style bible. Remove the clutter.

---

## Mood
Cozy, welcoming fishing village on a green island. Bright, sunny, the "home" island. It should feel like the first page of a storybook.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: grass top | Fresh green | `#6CCB4A` |
| Grass variation patch | Deeper green | `#4FA83A` |
| Secondary: rock (keep the periwinkle from the reef target) | Periwinkle | `#8A97E6` |
| Rock dark band | Deep periwinkle | `#5E6BC4` |
| Rock light band | Lavender | `#B3BCF2` |
| Sand | Butter yellow | `#F3DC9A` |
| Path stone | Warm gray | `#A8A3B8` |
| Wood | Warm brown / dark brown | `#9A6238` / `#6B4226` |
| Accents (props only) | Red, yellow, pink, sky blue | `#FF5A5A` `#FFD447` `#FF8FC7` `#4FC3F7` |

## Terrain
- 3 tiers: sandy beach ring, main grassy plateau, high hill with the landmark.
- Cliffs between tiers: big periwinkle slabs with a thin yellow strip (sand/dirt) just under the grass lip, like the current build has, but cleaner: one continuous band, not per-block.
- Grass tops: 2 tones in large soft patches. Add small flower clusters (3 to 5 flowers) only at rock bases and path edges.
- Replace the many thin rock spires on the beach with **3 hero sea stacks**: tall, angled slab towers with a grass cap and a few plants, like the reef pillars in the target.
- Waterfall: one small waterfall from the high hill into a pond near the plaza (bright blue Glass/ Neon-free parts with stud texture).

## Landmark
**Lighthouse on the high hill.** Chunky, slightly leaning, white and red bands, stone base, glowing lamp room at the top (Neon + PointLight). Wide stairs with a wooden railing and lanterns lead up to it (replacing the current tower).

## Zones (themed)
- **Main Dock:** Wooden pier with a wide T-shaped end. Posts with rope, lanterns, spear rack, bucket of fish, a little "SPEARFISHING" sign. Under the water: a full coral reef shelf in the exact target style (periwinkle rock, yellow sand, pink/orange/yellow/blue corals, green kelp).
- **Hub Plaza:** Round stone plaza with a fish statue fountain in the center. Benches in pairs. Flower planters at the edge.
- **Fish Market:** Open wooden stall with a striped red/white awning, ice crates with fish, a hanging scale, big fish-shaped sign.
- **Spear Shop:** Small cottage with a timber frame, blue roof, spears on a wall rack outside, a target board on the side wall.
- **Upgrade Station:** Carpenter's yard: shed, stacked logs, a sawhorse, a blueprint board on an easel.
- **Stone Arch (top left):** Keep it as a scenic feature, but rebuild it from big angled slabs with moss on top. Use it as the gate to the Travel Boat dock.
- **Travel Boat:** Small sailboat with a green sail moored at a second pier.

## Trees and plants
- Stylized pines in 3 sizes (keep pines, they work) PLUS round oak trees for variety near the village.
- Clumps of 3 to 7 trees with clear gaps. Fewer trees along the main path so it reads.
- Bushes: round 3-part bushes with a few red berries, in clusters.

## Shallow Reef Ring
Classic coral reef, matching the target image 1:1. This is the showcase.

## Lighting preset
- ClockTime 14, `Ambient #7A86A8`, `OutdoorAmbient #9AA6C8`
- Atmosphere color `#C7DFFF`, decay `#9FC4FF`
- ColorCorrection tint `#FFFFFF`, saturation 0.15
- Water color `#2E9BE6`

## Upgrade tiers
- **Tier 1:** Short pier, market and spear shop are simple stalls, plaza is dirt with a small well.
- **Tier 2:** T-shaped pier, shops become cottages, stone plaza, fountain, lanterns along path.
- **Tier 3:** Second fishing platform, flags and bunting across the plaza, lighthouse lit with rotating beam, flower boxes everywhere near buildings.

## Do NOT
- Do not scatter single green or gray blocks on the grass.
- Do not use per-block random grass tones.
- Do not make every tree the same pine.
