# MAP 3: FrostCoast (SNOW, 3rd island, origin 2600,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **FrostCoast** (see `references/current_generation/FrostCoast/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 4). Keep the good ideas (log cabin village, campfire, snowmen, frozen pond, frozen waterfall, icebergs) but rebuild everything to the style bible using the shared layout (section 4). Keep the Model name `FrostCoast`.

---

## Mood
Arctic fishing outpost. Crisp, cold, cozy lights against snow. Northern-village feel with ice fishing vibes.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: snow | Snow white (slightly blue) | `#F4F8FF` |
| Snow shadow patch | Pale blue | `#D6E4F5` |
| Secondary: rock | Slate lavender | `#7C86C9` |
| Rock dark band | Deep slate | `#565FA3` |
| Ice | Ice blue | `#9FD8F2` |
| Deep ice | Glacier blue | `#5BB6E3` |
| Wood | Red-brown / dark | `#8A4B32` / `#5A3222` |
| Pine foliage | Dark teal green | `#2F7A5E` |
| Accents (props only) | Warm orange, red, gold, cyan | `#FF8A3D` `#E8403A` `#FFC93C` `#3FE0F0` |

Warm accents (lanterns, cabin windows, red roofs) are what make snow maps look alive. Use them on every building.

## Terrain
- 3 tiers: icy shore shelf, main snowy plateau, tall glacier peak.
- Cliffs: big slate-lavender slabs with thick **snow caps** that overhang the edge by 1 to 2 studs, and a few ice-blue icicle clusters hanging under the overhangs.
- Snow ground: 2 tones in soft drifts, with snow mounds piled against building walls and rocks.
- Shoreline: flat ice sheets broken into large plates stepping into the water, with a few floating ice chunks (big, 6+ studs, not tiny).
- Frozen pond near the plaza with an ice-fishing hole and a little bench.
- Replace beach rock clutter with **3 hero ice formations**: angled glacier shards (ice blue with white tops).

## Landmark
**Glacier Peak with an Ice Crystal.** Tall angled glacier spire on the highest tier with a giant glowing cyan crystal at the top (Neon + PointLight, light bloom). Switchback path with lanterns and a wooden bridge over a crevasse leads up.

## Zones (themed)
- **Main Dock:** Heavy timber pier with snow on the planks and railings, ice-crusted posts, warm lanterns, a fire barrel, spear rack, fish crates. End platform has an ice-fishing-style hole cut in an adjacent ice sheet as decoration. Under the water: icy reef (see below).
- **Hub Plaza:** Cleared stone plaza with a big campfire ring in the center, logs as benches, a snowman, a carved fish totem pole.
- **Fish Market:** Log cabin stall with a red roof under snow, ice blocks holding fish, hanging dried fish, lantern-lit sign.
- **Spear Shop:** Two-story A-frame cabin, steep red roof with snow, chimney with smoke particles, warm orange windows, harpoons on a wall rack outside.
- **Upgrade Station:** Lumber camp: sled stacked with logs, axe in a stump, workshop shed, blueprint board.
- **Travel Boat:** Small icebreaker boat with a red hull at a second pier.

## Trees and plants
- Snowy pines in 3 sizes: dark teal tiers with white snow on the top of each tier.
- Dead/bare trees (thin, 2 to 3 branches) in a few spots for contrast.
- Snow-covered bushes and frosty grass tufts at rock bases.
- Clumps of 3 to 7 pines, gaps between clumps.

## Shallow Reef Ring
Cold-water reef: slate rock shelves with ice-blue crystals, kelp forests (tall dark green and teal kelp), white and pale pink anemones, starfish, a few sea urchin clusters (purple). Keep the chunky coral-reef shapes from the target, just recolored cold.

## Lighting preset
- ClockTime 16.5 (low golden-cold sun), `Ambient #7880A8`, `OutdoorAmbient #A8B4D8`
- Atmosphere color `#DCE8FF`, decay `#A8C0F0`, Density 0.3
- ColorCorrection tint `#F0F6FF`, saturation 0.1
- Water color `#3A8FC9`
- Optional: light snowfall particle emitter around the player (low rate).

## Upgrade tiers
- **Tier 1:** Short pier, market is a tent with ice blocks, small campfire, no lanterns.
- **Tier 2:** Full timber pier, log cabins, plaza with totem and campfire ring, lanterns along path.
- **Tier 3:** Second platform, string lights between cabins, crystal on the peak glows and pulses, aurora effect in the sky (optional skybox swap).

## Do NOT
- Do not make the map all white. Snow needs blue shadow tones, warm lights, and red roofs for contrast.
- Do not scatter small ice cubes or snow blocks around.
- Do not use gray for rock; use the slate lavender so it matches the reef style.
