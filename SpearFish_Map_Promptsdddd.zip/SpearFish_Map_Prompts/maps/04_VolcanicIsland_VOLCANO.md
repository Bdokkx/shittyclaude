# MAP 4: VolcanicIsland (VOLCANO, final island, origin 3900,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **VolcanicIsland** (see `references/current_generation/VolcanicIsland/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 5). Keep the good ideas (crater lava pool, lava falls, basalt columns as a few hero clusters, braziers, stilt-hut village) but rebuild everything to the style bible using the shared layout (section 4). Remove the pine trees. Keep the Model name `VolcanicIsland`.

---

## Mood
Dramatic end-game island. Dark rock, glowing lava, warm orange light. Dangerous but still toy-like and colorful, not grim. Think stylized cartoon volcano, not realistic.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: basalt rock | Purple-black | `#3A3346` |
| Rock mid band | Dusty purple | `#57496B` |
| Rock light band / ash ground | Ash mauve | `#7A6C85` |
| Black sand beach | Charcoal | `#2E2A33` |
| Lava (Neon material) | Hot orange / yellow core | `#FF5A1F` / `#FFB01F` |
| Cooling lava crust | Deep red | `#B5301E` |
| Wood (charred) | Dark brown | `#4A2E22` |
| Accents (props only) | Teal crystals, sulfur yellow, red banners | `#33E0C0` `#F2D43A` `#E83A3A` |

Keep the rock purple-tinted so it fits the periwinkle family of the reef target, just much darker. The teal crystals are the cool accent that balances all the orange.

## Terrain
- 3 tiers: black sand beach, main plateau with the village (built on cooled lava rock), and the volcano cone.
- Cliffs: big angled basalt slabs, with a few **hexagonal basalt column clusters** (like Giant's Causeway) as hero features at the shore.
- **Lava rivers:** 2 lava channels flowing from the volcano down to the sea, built from Neon parts with a darker crust edge on each side. Where lava meets the ocean, add a steam particle cloud and a rock arch.
- Ash ground: 2 tones in large patches, plus small glowing cracks (thin Neon orange lines) only in a few deliberate spots.
- Teal crystal clusters (3 to 5 crystals each) at cliff bases and cave mouths.
- Wooden or stone bridges cross the lava rivers on the main path.

## Landmark
**The Volcano.** Huge stepped cone made of angled slabs (not a smooth mesh), glowing lava pool in the crater, lava light bloom, smoke particles rising. Visible from everywhere. Optional: a small obsidian shrine on the crater rim with a giant teal crystal.

## Zones (themed)
- **Main Dock:** Stone-and-charred-wood pier with metal braziers (fire particles), a big spear rack, heat-proof fish crates, red banners. Under the water: volcanic reef (see below).
- **Hub Plaza:** Obsidian-tiled plaza (2 tones in a pattern), centerpiece is a lava fountain: a stone bowl with a glowing Neon lava pool and a fish statue.
- **Fish Market:** Stone stall built into the rock with a red cloth awning, fish on cooling rocks, hanging lanterns.
- **Spear Shop:** Blacksmith forge: stone building with a big chimney, glowing furnace, anvil, spears cooling in a rack, sparks particles.
- **Upgrade Station:** Obsidian quarry: cut stone blocks, a crane made of wood and rope, minecart with crystals.
- **Travel Boat:** Armored boat with an iron hull at a second pier (final island, so this can travel back to earlier islands).

## Trees and plants
- Charred dead trees (black trunks, a few branches) in clumps.
- A few hardy palms with orange-tinted fronds near the beach for color.
- Glowing mushrooms (teal caps) and fire flowers (orange) in small clusters at rock bases.

## Shallow Reef Ring
Volcanic reef: dark basalt shelves, glowing hydrothermal vents (Neon orange cracks with bubble particles), teal and purple tube corals, red anemones, crystal clusters. Same chunky shelf shapes as the target, just dark rock with glowing accents.

## Lighting preset
- ClockTime 18.5 (sunset), `Ambient #6A4050`, `OutdoorAmbient #8A5060`
- Atmosphere color `#FF9A6A`, decay `#6A3A5A`, Density 0.35, Haze 2
- ColorCorrection tint `#FFE8DC`, saturation 0.2, contrast 0.1
- Bloom intensity 0.6 (lava glow)
- Water color `#1F6E9E` (darker)
- Optional: ash particles floating in the air (very low rate).

## Upgrade tiers
- **Tier 1:** Short stone pier, market is a cloth tent, forge is a single anvil and fire pit, plaza is bare ash ground.
- **Tier 2:** Full pier with braziers, stone buildings, obsidian plaza, lava fountain, bridges over lava.
- **Tier 3:** Second fishing platform, red banners everywhere, crater shrine crystal glows, extra lava falls, teal crystal lanterns along the path.

## Do NOT
- Do not make it all black and orange. Use the purple rock bands and teal accents.
- Do not cover the ground in glowing cracks; keep them rare and deliberate.
- Do not build the volcano as one smooth gray cone. Use stacked angled slabs with strata bands.
- Do not place lava where players walk without a clear bridge or barrier.
