# MAP 2: DesertCoast (DESERT, 2nd island, origin 1300,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **DesertCoast** (see `references/03`, `04`, `05` and `references/current_generation/DesertCoast/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 3). Keep the Model name `DesertCoast`. Keep the layout idea (long pier into the center, village plaza in the middle, mesas around the edge, temple arch top left, waterfall mesa top center) but rebuild everything to the style bible. This island has the WORST clutter problem: remove every loose brick on the sand and plateaus.

---

## Mood
Sun-baked oasis trading town on red rock mesas. Warm, bright, bustling market energy.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: sand | Light sand | `#F2DDAE` |
| Sand patch variation | Warm sand | `#E8C98A` |
| Secondary: mesa rock | Terracotta | `#C8654A` |
| Rock dark band | Rust | `#9E4A3A` |
| Rock light band | Peach | `#E89C78` |
| Adobe walls | Clay | `#E3A46F` |
| Adobe trim | Dark clay | `#B87447` |
| Wood | Tan / brown | `#C08A55` / `#7A4E2D` |
| Oasis water | Turquoise | `#3EC6D9` |
| Accents (props only) | Turquoise, red, yellow, cactus green | `#3EC6D9` `#F2484B` `#FFD23F` `#3FAE4A` |

## Terrain
- 3 tiers: wide sand beach, main sandy plateau with the town, tall mesas around the edge.
- **Mesas:** the big change. Rebuild as large flat-topped terracotta slabs stacked in clear horizontal strata bands (light / mid / dark), with slight tilts and overhanging lips. Tops are sand-colored caps. Reference: real Monument Valley strata, but chunky and toy-like.
- Sand: 2 tones in big dune-shaped patches. NO scattered tiny bricks, pebbles, or cubes.
- Beach rocks: replace all the small red/white rock lumps with **3 hero rock arches or hoodoos** on the beach.
- **Oasis:** small turquoise pool near the plaza with palms and reeds around it (replaces the random blue part).
- Waterfall: keep the waterfall mesa, make the fall wider (6+ studs) and land in a turquoise pool.

## Landmark
**Sun Temple on the tallest mesa (top left).** Big stepped temple with a giant arch and a golden sun disc on top (Neon gold + light). Wide carved staircase with torches leading up. Visible from the end of the pier.

## Zones (themed)
- **Main Dock:** Long sun-bleached wooden pier with a wide T end (current pier is a good start). Add rope railings, clay pots, spear rack, a shade canopy (striped cloth) at the end, lanterns. Rowboat tied to the side. Under the water: coral reef with warmer corals (orange, red, yellow) and sand-colored rock mixed with periwinkle.
- **Hub Plaza:** Tiled sandstone plaza (2 tones in a simple pattern, not random). Centerpiece: stone well with a turquoise water top and a little roof. Palm planters at the corners.
- **Fish Market:** Bazaar stall row: 3 stalls with striped awnings (red/yellow/turquoise), baskets of fish, clay jars, hanging fish, rug on the ground.
- **Spear Shop:** 2-story adobe building with rounded corners, wooden beams poking out of the walls (vigas), a balcony, spears displayed on the wall, big spear sign.
- **Upgrade Station:** Mud-brick workshop with scaffolding, stacked clay bricks, a camel-cart of supplies.
- **Travel Boat:** Small dhow-style boat with a triangular cream sail at a second pier.

## Building fixes (from reference 05)
The current adobe houses are flat boxes. Fix:
- Rounded or beveled corners, slightly tapered walls.
- Darker clay plinth at the base, lighter trim band at the roofline.
- Recessed windows with wooden frames and turquoise shutters.
- Viga beams sticking out under the roofline.
- Rooftop details: water jar, small dome, or rooftop canopy.
- Doors with frames, steps, and a pot cluster beside them.
- Scale all lanterns, tables, and the well up to player size (style bible 5.4).

## Trees and plants
- Stylized palms in 3 sizes: segmented curved trunk (3 to 5 tilted segments), 5 to 7 big clean leaf fronds. No voxel smears.
- Cacti: saguaro style in 2 to 3 sizes, clustered with a rock or near a building, never alone in open sand.
- Desert shrubs and dry grass tufts only at rock bases and path edges.

## Shallow Reef Ring
Warm coral reef: orange, red, and yellow tube corals, sand shelves, a few clam shells and a sunken clay pot cluster.

## Lighting preset
- ClockTime 15, `Ambient #A08070`, `OutdoorAmbient #C8A890`
- Atmosphere color `#FFE2B8`, decay `#FFC98A`, Haze 1.5
- ColorCorrection tint `#FFF4E6`, saturation 0.2
- Water color `#2DB8E0`

## Upgrade tiers
- **Tier 1:** Short pier, one bazaar stall, spear shop is a tent, plaza is plain sand with a small well.
- **Tier 2:** T pier with canopy, 3 bazaar stalls, adobe spear shop, tiled plaza, oasis pool.
- **Tier 3:** Second pier platform, banners strung across the plaza, Sun Temple disc glows, extra palms and lanterns.

## Do NOT
- Do not leave a single loose brick on the sand. Search and delete.
- Do not dot red rocks randomly across the beach.
- Do not mix stud sizes (reference 05 has huge studs next to tiny studs).
