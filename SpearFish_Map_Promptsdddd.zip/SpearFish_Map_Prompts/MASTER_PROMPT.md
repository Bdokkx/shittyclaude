# MASTER PROMPT: Spearfishing Islands (All 4 Maps)

You are a senior Roblox environment artist and level designer who specializes in high-quality stud-style maps. I am attaching reference images. `references/01_STYLE_TARGET_coral_reef.png` is the exact look I want. Everything else in `references/` (images 02 to 05 and the whole `current_generation/` folder) shows my CURRENT maps and what is wrong with them.

The maps are: **VoxelIsland** (grass, starter), **DesertCoast** (desert), **FrostCoast** (snow), **VolcanicIsland** (volcano), plus the **CoralReef** underwater style used in the reef ring around each island.

Your job:
1. REBUILD all four islands so they match the target style and remove all the clutter and color noise.
2. Make every building much higher quality than the current ones.
3. Add the gameplay layout: spearfishing dock, Fish Market, Spear Shop, Island Upgrade Station, Travel Boat, landmark, and 3 upgrade tiers.
4. Follow every rule below. Work in stages (terrain > dock and reef > buildings > props > lighting) and show screenshots after each stage. Run the self-review checklist before calling any island done.

Build order: VoxelIsland first (get it approved), then DesertCoast, FrostCoast, VolcanicIsland. Every later island must match the approved VoxelIsland quality.

---


## 1. You are building

A Roblox spearfishing game in a chunky, toy-like **stud style**. The player stands on a dock, shoots fish in the water with a speargun, sells fish at the market, buys better spearguns, upgrades their island, then travels to the next island and repeats.

Island progression (level gated), using the real map names:
**VoxelIsland (Grass, start) > DesertCoast (Desert) > FrostCoast (Snow) > VolcanicIsland (Volcano).** Plus the **CoralReef** underwater map. Keep these Model names and their Studio origins (0,0,0 / 1300,0,0 / 2600,0,0 / 3900,0,0 / reef at 0,0,900).

Your job: build or rebuild each island so it looks intentional, high quality, and matches **`references/01_STYLE_TARGET_coral_reef.png`**. That image is the target. The other reference images show the CURRENT maps and what is wrong with them. `references/current_generation/` has overview, village, cliff and asset shots of every current map; `01_CURRENT_GENERATION_PROBLEMS.md` lists every problem in them. Note: `current_generation/CoralReef/CoralReef_GENERATED_not_target.jpg` is the low-quality generated reef, NOT the target.

---

## 2. What the target image does right (copy this)

Study `01_STYLE_TARGET_coral_reef.png` and match these qualities:

1. **Big, chunky forms.** Rock is built from large stacked slabs and shelves (4 to 16 studs wide, 2 to 6 studs thick), not hundreds of 1x1 cubes.
2. **Angled layering.** Slabs are tilted 5 to 20 degrees and offset from each other so they overhang like shelves. Nothing is a perfect staircase of cubes.
3. **One consistent stud texture.** Every surface has the same inset-square stud pattern at the SAME world scale. A stud on a cliff is the same size as a stud on a crate.
4. **Limited palette.** One dominant base color (periwinkle rock), one secondary (butter sand), and a set of bright accents used only on props (corals). Each material reads as one clear color with gentle tone variation.
5. **Props are grouped on purpose.** Corals come in clusters of 2 to 4 tubes on a shared base. Clusters sit on ledges, at the base of rocks, or along edges. Nothing floats randomly in open ground.
6. **Clean negative space.** Large areas of floor are left open and calm so the props and rock forms stand out.
7. **Readable silhouettes.** You can tell what every object is from far away.

---

## 3. What is wrong with the current maps (fix this)

See references 02 to 05 and everything in `references/current_generation/`. Full per-map list in `01_CURRENT_GENERATION_PROBLEMS.md`.

| Problem | Where you can see it | Fix |
|---|---|---|
| Hundreds of loose 1x1 and 2x1 bricks scattered on sand and grass | 03, 04 (beach, plateaus) | Delete them. Props only appear in deliberate clusters (rule 5.2). |
| Ground is a noisy checkerboard of random tones | 02 (grass), 05 (village floor) | Use 2 to 3 tones in large organic patches, 8x8 studs or bigger. |
| Cliffs are stair-stepped voxel cubes with per-block color noise | 02, 03 | Rebuild as large angled slabs and shelves with 2 to 3 horizontal color bands. |
| Buildings are plain boxes with a hole for a window | 05 | Follow the Building Quality Standard (section 6). |
| Stud texture scale is inconsistent (huge studs on some parts, tiny on others) | 05 | One MaterialVariant, fixed StudsPerTile (section 7). |
| Random rock lumps dotted around the beach | 03, 04 | Replace with 2 to 4 hero rock formations placed with purpose. |
| Props too small for the player (lamps, tables, well) | 05 | Scale to the player (section 5.4). |
| Palms/trees look like noisy voxel smears | 03, 04 | Build clean stylized trees with 3 to 5 big leaf shapes (section 6.4). |
| No clear focal point or path; eye has nowhere to go | 02, 03 | Dock > plaza > shops > landmark path (section 4). |
| Lumpy, triangulated "deformed mesh" rocks next to clean blocks (two styles fighting) | current_generation `_cliffs`, `_assets` | Use crisp chunky slab rocks like the target. No noisy faceted blobs. |
| Trees carpeted evenly over every slope | current_generation `_poster` | Clumps of 3 to 7 with clear gaps; paths and plaza stay clear. |
| Same spiral staircase mountain on every island | current_generation `_poster` top views | Use the shared gameplay layout (section 4). |
| 32k to 35k parts per island, mostly clutter | repo README | Under 12,000 parts per island. |

---

## 4. Island layout (same for every island)

Every island uses the same gameplay layout so players learn it once.

```
          [ LANDMARK ]        <- tallest point, visible from the dock
               |
      [ UPGRADE STATION ]     <- island upgrade hut / builder yard
           /       \
 [ FISH MARKET ]  [ SPEAR SHOP ]
           \       /
         [ HUB PLAZA ]        <- spawn, open, clean floor
               |
          main path (6-8 studs wide)
               |
         [ MAIN DOCK ]  ->  spearfishing water + shallow reef ring
               |
        [ TRAVEL BOAT ]       <- go to next island (locked until level)
```

**Required zones per island:**

1. **Main Dock (spearfishing spot).** Wide platform (at least 24x16 studs at the end) so many players can shoot at once. Railings with gaps to shoot through, spear racks, bait buckets, lanterns on posts, rope coils. The water below must look rich: a shallow reef shelf in the coral reef style, visible through clear water, so players WANT to shoot there.
2. **Hub Plaza.** Spawn point. Open, readable, clean floor with one centerpiece (statue, well, fountain, totem). Shops face the plaza.
3. **Fish Market (sell).** Stall or building with a big readable sign, ice boxes, hanging fish, scale/weighing station, crates.
4. **Spear Shop (buy spearguns).** Spears displayed on wall racks and a counter, target dummy or practice board, signage.
5. **Island Upgrade Station.** Builder hut or workshop with scaffolding, lumber piles, a blueprint board.
6. **Landmark.** One tall hero structure per island, visible from the dock (lighthouse, temple, ice spire, volcano peak).
7. **Travel Boat / Dock 2.** Boat or second pier that teleports to the next island.
8. **Shallow Reef Ring.** Underwater shelf around the island in the coral reef style, themed to the biome (section 8 in each map file).

**Island Upgrade Tiers.** Build each island so it visibly improves when the player upgrades. Make 3 tiers as separate Models (`Tier1`, `Tier2`, `Tier3`) that a script can toggle:
- Tier 1: small, humble. Short dock, simple stalls, few decorations.
- Tier 2: dock extended, stalls become buildings, more lanterns and flags.
- Tier 3: big dock with a second platform, fully decorated buildings, landmark lit up, extra hero props.

---

## 5. Composition rules (the anti-clutter rules)

### 5.1 Density
- Leave **at least 40% of walkable ground** as clean open floor.
- Detail goes where players look: around the dock, the plaza, building entrances, and along path edges. Far corners stay simple.

### 5.2 Clusters, not scatter
- **No loose single parts.** Delete any part smaller than 2x2 studs that is not part of a building or cluster.
- Props come in **clusters of 3 to 5** objects of varying size (1 large, 1 to 2 medium, 1 to 2 small).
- Every cluster is **anchored to something**: a wall base, a rock, a path edge, a dock post. Never in the middle of open ground.
- Rocks: use **2 to 4 hero rock formations** per beach, not 30 small rocks.

### 5.3 Color
- **60 / 30 / 10 rule.** 60% dominant base, 30% secondary, 10% bright accents.
- Bright accents go ONLY on props, signs, awnings, flowers, corals, lanterns. Never on terrain.
- Terrain gets tone variation in **large patches** and **horizontal bands** on cliffs (2 to 3 bands: light top, mid, dark base). No per-block random tones.

### 5.4 Scale (player is about 5 studs tall)
- Door: 4 wide, 7 to 8 tall.
- One-story building: 10 to 14 studs tall to roof peak.
- Lamp post: 8 to 10 studs.
- Market stall counter: 3.5 studs tall.
- Paths: 6 to 8 studs wide. Plaza: 30x30 studs minimum.
- Trees: 14 to 25 studs tall.

### 5.5 Forms
- Terrain is built in **3 height tiers**: beach level, main island level, high ground with landmark. Connect them with wide, clear stairs or ramps.
- Cliffs: stack big slabs with overhanging lips (1 to 3 studs) and slight tilts, like the reef shelves.
- Shorelines: clean beach terraces that step down into the water in 2 to 3 wide shelves, then the reef ring.
- Avoid perfect symmetry and perfect straight lines on natural forms. Man-made things (dock, buildings) can be straight but may lean slightly for charm.

### 5.6 Readability
- From the dock, a new player must see: the plaza, at least two shops, and the landmark.
- Paths lead the eye: dock > plaza > shops > landmark.
- Use lanterns or torches along the main path as guides.

---

## 6. Building Quality Standard

Every building and structure must have **3 layers of detail**:

1. **Primary form.** Interesting shape, not a box. Use L-shapes, offset second floors, tapered walls, slightly leaning walls, stepped roofs.
2. **Secondary details.** Foundation plinth (1 to 2 studs, darker tone). Corner pillars or edge trim in a contrasting tone. Windows recessed 0.5 to 1 stud with frames and sills. Roof overhangs 1 to 2 studs with a fascia/edge band. Door frame and step.
3. **Tertiary props.** A prop cluster at the entrance (crates, barrels, sign, lantern, plant pot). Awnings, banners, hanging signs, chimneys.

**Rules:**
- No flat wall area bigger than 10x10 studs without a break (window, trim, beam, color band).
- Every shop has a **big readable sign** with an icon (fish, spear, hammer).
- Roofs are a different color from walls.
- Wood: show planks with 2 alternating tones, visible posts and beams.

### 6.4 Trees and plants
- Trees: thick trunk built from 2 to 4 angled segments, canopy made from 3 to 5 large leaf shapes or tiers. No noisy voxel leaves.
- Use 3 sizes of each tree type and rotate them so they don't look copy-pasted.
- Group trees in clumps of 3 to 7 with gaps between clumps. Not an even carpet.
- Plants and flowers: clusters at rock bases and path edges, like the corals in the target.

---

## 7. Technical setup (Roblox Studio)

### Stud texture
- Create ONE `MaterialVariant` named `StudInset` (inset-square stud pattern like the target image) under `MaterialService`, based on `Plastic`.
- Set `StudsPerTile` so that **one stud on the texture = one stud in the world** (usually `StudsPerTile = 1` for a single-stud tile, or match the tile size of your texture).
- Use `TexturePack` / MaterialVariant only. Do NOT use Decals or Textures per part for studs (causes scale mismatch).
- Optional: a second variant `StudFlat` (smaller, subtle) for water-adjacent sand and paths.

### Grid
- Move snap: 1 stud (0.5 for small details). Rotation snap: 15 degrees for terrain slabs, 5 for fine tuning.
- Part sizes are whole studs or half studs.

### Performance
- All parts `Anchored = true`.
- Decorative parts: `CanCollide = false`, `CanTouch = false`, `CanQuery = false` where possible.
- Small props: `CastShadow = false`.
- Repeated props (trees, crates, lanterns, corals, rocks) are **Packages or MeshParts** so they are reused, not rebuilt.
- `Workspace.StreamingEnabled = true`.
- Budget: aim for under **12,000 parts per island** (use bigger slabs instead of many small blocks; this also fixes the clutter look).
- Organize: `Workspace/Islands/<IslandName>/{Terrain, Buildings, Props, Dock, Reef, Lighting, Tier1, Tier2, Tier3, Spawns}`.

### Lighting (base, adjust per biome in map files)
- `Lighting.Technology = Future` (or `ShadowMap` for low-end).
- `Brightness = 2.5`, `EnvironmentDiffuseScale = 0.5`, `EnvironmentSpecularScale = 0.3`.
- `ColorCorrectionEffect`: Saturation 0.15, Contrast 0.05.
- `Atmosphere`: Density 0.25, Haze 1, Glare 0 (tint per biome).
- `BloomEffect`: Intensity 0.4, Size 24, Threshold 1.5 (for lanterns and lava).
- Each island has a lighting preset folder that a script applies on teleport.

### Water
- Clear, saturated blue water. If using Terrain water: `WaterTransparency = 0.6` or higher so the reef ring is visible from the dock, `WaterReflectance = 0.1`, `WaterWaveSize = 0.1`.
- Water color tinted per biome.

---

## 8. Self-review checklist (do this before saying you are done)

Take screenshots from: (a) the end of the dock looking at the island, (b) overhead at 45 degrees like reference 02, (c) the plaza at player height. Compare each against `01_STYLE_TARGET_coral_reef.png`.

- [ ] Same stud size on every surface.
- [ ] No loose single bricks anywhere. Searched and deleted parts under 2x2 that are not in a cluster.
- [ ] At least 40% clean open ground.
- [ ] Cliffs are big angled slabs with color bands, not stair-stepped cubes.
- [ ] Every building has foundation, trim, recessed windows, overhanging roof, entrance prop cluster, sign.
- [ ] Dock is wide, decorated, and has a visible reef below.
- [ ] Landmark is visible from the dock.
- [ ] Palette follows 60 / 30 / 10 with accents only on props.
- [ ] Tier1, Tier2, Tier3 models exist and toggle cleanly.
- [ ] Part count under budget, decor has collisions off.

If any box fails, fix it and re-check.


---
---

# CURRENT GENERATION PROBLEMS (read with the style bible)

The current maps come from the generator in `Bdokkx/shittyclaude` > `roblox-island/` (branch `claude/jolly-bardeen-kv6g11`). Photos of every map are in `references/current_generation/`. This file lists exactly what is wrong in them so it does not happen again.

| Real map name | Theme | Origin in Studio | Map prompt |
|---|---|---|---|
| **VoxelIsland** | Grass (starter) | 0, 0, 0 | `maps/01_VoxelIsland_GRASS.md` |
| **DesertCoast** | Desert | 1300, 0, 0 | `maps/02_DesertCoast_DESERT.md` |
| **FrostCoast** | Snow | 2600, 0, 0 | `maps/03_FrostCoast_SNOW.md` |
| **VolcanicIsland** | Volcano | 3900, 0, 0 | `maps/04_VolcanicIsland_VOLCANO.md` |
| **CoralReef** | Underwater reef | 0, 0, 900 | see section 6 below |

Keep these names and origins so existing scripts (LightingAndWater.lua, MeshSwap.lua, teleports) still work.

---

## 1. Problems on EVERY map (from `00_ALL/AllIslands.jpg`)

1. **Clutter everywhere.** About 32,000 to 35,000 parts per island, and the README admits it is "mostly clutter". Tufts, small rocks, flowers, and bushes are sprinkled evenly over every walkable tile. There is no clean ground anywhere.
2. **Checkerboard color noise.** Every ground tile and cliff block picks a random shade, so grass, sand, cobble, snow and ash all look like static. The target reef uses calm, solid colors.
3. **Stair-stepped voxel terrain.** Cliffs are stacks of 1-block steps with random tones instead of big angled slabs with clean horizontal bands.
4. **Two styles fighting.** Clean blocky parts sit next to lumpy, triangulated "deformed mesh" rocks (cliff walls, crags, boulders). They do not match each other or the target. The target uses crisp, chunky slab shapes with the stud texture, not noisy faceted blobs.
5. **Too many trees in an even carpet.** Trees fill every gap, which hides the layout and the paths.
6. **Weak buildings.** Houses are plain boxes with black-square windows (see every `_assets.jpg`). No trim, no inset frames, no roof overhang, no entrance props, no signs.
7. **No gameplay layout.** There is no Fish Market, Spear Shop, Upgrade Station, or Travel Boat. The dock is a generic T-pier with no spearfishing setup and no reef visible under it.
8. **Spiral paths.** Every island uses the same spiral staircase up a mountain. It reads as generated, not designed.
9. **Small props at the wrong scale.** Torches, wells, stalls and pots are tiny compared to the player.

---

## 2. VoxelIsland (Grass) problems
Photos: `current_generation/VoxelIsland/` and `references/02_CURRENT_grass_island_overview.png`

- Grass tops are a noisy mix of 4 greens plus moss; cliffs mix periwinkle, gray, dark and moss blocks at random.
- Cobblestone plaza is a random 5-tone checkerboard; the plaza does not read as one place.
- Sea stacks and cliff rocks are lumpy mesh blobs covered in green moss noise.
- Small gray rocks scattered across the beach for no reason.
- The village is 1 stall, a few benches and a campfire. Nothing a player can use.
- The summit lookout is a tiny stone stub; not a real landmark.
- **Keep:** the periwinkle + green + yellow sand-band color idea, the stone arch idea, the T-dock position, the pine trees (just fewer and clumped).

## 3. DesertCoast (Desert) problems
Photos: `current_generation/DesertCoast/` and `references/03`, `04`, `05`

- Worst clutter of all four: hundreds of small red/tan/green blocks on every sand surface.
- Sand floor is a random 3-tone checkerboard; the plateau tops look dirty.
- Red rock is noisy (red, dark red, light red, terracotta at random) instead of clean strata bands.
- Beach "desert rocks" are lumpy mesh blobs dotted randomly around the shore.
- Adobe houses are boxes with black holes and a blue table stuck to the front (`DesertCoast_assets.jpg`).
- Palm trees are noisy voxel smears; too many of them, evenly spread.
- Stud texture scale differs between the village floor (big studs) and the cliffs (tiny studs).
- The ziggurat landmark is small and plain; the waterfall is a thin blue strip.
- **Keep:** the oasis lake, the mesa ring around the edge, the ziggurat/temple idea, the striped market stalls, the long pier.

## 4. FrostCoast (Snow) problems
Photos: `current_generation/FrostCoast/`

- Almost everything is the same white/pale blue, so nothing stands out. No warm contrast.
- Cliffs are noisy stacks of white, pale blue and ice blocks; it reads as a blur.
- Plaza is a random gray/blue checkerboard.
- Log cabins are plain boxes with a striped roof and two glowing squares. All four are nearly identical.
- Way too many snow pines, evenly carpeted over every slope.
- Ice crystals and icebergs are lumpy mesh blobs.
- The summit "flag lookout" is a thin pole, not a landmark.
- **Keep:** the log cabin + campfire + snowman village idea, the frozen pond, the frozen waterfall, icebergs offshore (fewer, bigger, cleaner).

## 5. VolcanicIsland (Volcano) problems
Photos: `current_generation/VolcanicIsland/`

- Colors are muddy brown and gray. Nothing ties it to the reef's periwinkle family. No cool accent to balance the orange.
- Ground is a random mix of gray, dark gray, brown and red blocks; very noisy and dark.
- Lava rivers are thin yellow zigzags that look like lines painted on the ground, not flowing lava with crust edges.
- Basalt columns and obsidian shards are scattered everywhere as small spikes.
- The volcano is not a readable cone; from the overview it is a lumpy hill. There is no clear crater landmark.
- Pine trees on a volcano island break the theme.
- Stilt huts are all the same tiny box with a red roof.
- **Keep:** the lava pool crater idea, lava falls, basalt columns (as 2 to 3 hero clusters), braziers, the stilt-hut village idea (but varied and bigger).

## 6. CoralReef (generated) problems
Photo: `current_generation/CoralReef/CoralReef_GENERATED_not_target.jpg`

This is **NOT** the target. The target is `references/01_STYLE_TARGET_coral_reef.png`. Differences:
- Generated: corals are spaced evenly in a grid-like spread across flat sand. Target: corals are grouped on ledges and rock bases with open sand between.
- Generated: rocks are small, separate lumps. Target: big stacked, tilted shelves that form a connected reef wall with overhangs.
- Generated: kelp is everywhere. Target: kelp is used in a few tall clumps.
- Generated: coral pieces are thin pixel sticks. Target: corals are chunkier tubes and fans with a clear brown base.
- Use the target style for the shallow reef ring around every island.

---

## 7. Root causes in the generator (for whoever edits `roblox-island/gen/`)

If the maps are regenerated with code instead of rebuilt by hand, fix these first:

| Cause | File | Fix |
|---|---|---|
| Clutter is a per-tile random chance (for example `GrassTuft 0.13`, `Fern 0.05`, `SmallRock 0.02`) on every walkable tile, plus `beach_clutter` and `path_clutter` lists | `gen/themes.py`, `gen/island.py` | Remove per-tile clutter. Place props as **clusters of 3 to 5** at chosen anchor points only (cliff feet, building walls, path edges, dock posts), with a minimum spacing between clusters. Delete `SmallRock` / `*Rock` from beach and path clutter entirely. Target **under 12,000 parts per island**. |
| Every tile picks a weighted random color (for example `top=[grass 6, grass_dark 2.5, grass_light 2, moss 0.6]`, `rock` has 7 shades) | `gen/themes.py`, `gen/island.py` | Use ONE base color per surface. Add variation with **low-frequency noise patches** (8x8 studs or bigger) of at most 2 extra tones. Cliff color comes from **height bands** (light top, mid, dark base), never per-block random. Remove `rock_gray` and `moss` from rock lists. |
| Cobble/plaza uses 5 random tones | `gen/island.py` (cobble) | Use 2 tones in a regular pattern or one solid tone with a border. |
| Cliffs are 1-block height steps | `gen/island.py` | Build cliffs from large slabs (4 to 16 studs wide, 2 to 6 thick) with slight tilt and 1 to 3 stud overhang lips. |
| Deformed mesh rocks (voxel remesh + noise + decimate) look lumpy and do not match the parts | `tools/blender_meshes.py`, `roblox/MeshSwap.lua` | Drop the noisy deformation. Rocks should be chunky angled slabs like the target reef. Keep meshes only for reusing shapes, not for adding noise. |
| `tree_density` 1.0 to 1.15 fills every gap | `gen/themes.py` | Lower density and place trees in clumps of 3 to 7 with clear gaps. Keep paths and the plaza free of trees. |
| Same spiral path layout on every island | `gen/island.py` | Use the shared layout in style bible section 4 (dock > plaza > shops > upgrade station > landmark). |
| Building assets are plain boxes | `gen/assets.py`, `gen/theme_assets.py` | Rebuild buildings to the Building Quality Standard (style bible section 6). |
| Stud texture scale differs between parts and meshes | `tools/blender_meshes.py` UVs, MaterialVariant | One stud texture, one world scale everywhere (style bible section 7). |


---
---

# MAP 1: VoxelIsland (GRASS, starter island, origin 0,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **VoxelIsland** (see `references/02_CURRENT_grass_island_overview.png` and `references/current_generation/VoxelIsland/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 2). Keep the Model name `VoxelIsland`. Keep the general layout idea (dock bottom left, plaza in the middle, tower on the hill, stone arch top left) but rebuild every surface to the style bible. Remove the clutter.

---

## Mood
Cozy, welcoming fishing village on a green island. Bright, sunny, the "home" island. It should feel like the first page of a storybook.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: grass top | Fresh green | `#6CCB4A` |
| Grass variation patch | Deeper green | `#4FA83A` |
| Secondary: rock (keep the periwinkle from the reef target) | Periwinkle | `#8A97E6` |
| Rock dark band | Deep periwinkle | `#5E6BC4` |
| Rock light band | Lavender | `#B3BCF2` |
| Sand | Butter yellow | `#F3DC9A` |
| Path stone | Warm gray | `#A8A3B8` |
| Wood | Warm brown / dark brown | `#9A6238` / `#6B4226` |
| Accents (props only) | Red, yellow, pink, sky blue | `#FF5A5A` `#FFD447` `#FF8FC7` `#4FC3F7` |

## Terrain
- 3 tiers: sandy beach ring, main grassy plateau, high hill with the landmark.
- Cliffs between tiers: big periwinkle slabs with a thin yellow strip (sand/dirt) just under the grass lip, like the current build has, but cleaner: one continuous band, not per-block.
- Grass tops: 2 tones in large soft patches. Add small flower clusters (3 to 5 flowers) only at rock bases and path edges.
- Replace the many thin rock spires on the beach with **3 hero sea stacks**: tall, angled slab towers with a grass cap and a few plants, like the reef pillars in the target.
- Waterfall: one small waterfall from the high hill into a pond near the plaza (bright blue Glass/ Neon-free parts with stud texture).

## Landmark
**Lighthouse on the high hill.** Chunky, slightly leaning, white and red bands, stone base, glowing lamp room at the top (Neon + PointLight). Wide stairs with a wooden railing and lanterns lead up to it (replacing the current tower).

## Zones (themed)
- **Main Dock:** Wooden pier with a wide T-shaped end. Posts with rope, lanterns, spear rack, bucket of fish, a little "SPEARFISHING" sign. Under the water: a full coral reef shelf in the exact target style (periwinkle rock, yellow sand, pink/orange/yellow/blue corals, green kelp).
- **Hub Plaza:** Round stone plaza with a fish statue fountain in the center. Benches in pairs. Flower planters at the edge.
- **Fish Market:** Open wooden stall with a striped red/white awning, ice crates with fish, a hanging scale, big fish-shaped sign.
- **Spear Shop:** Small cottage with a timber frame, blue roof, spears on a wall rack outside, a target board on the side wall.
- **Upgrade Station:** Carpenter's yard: shed, stacked logs, a sawhorse, a blueprint board on an easel.
- **Stone Arch (top left):** Keep it as a scenic feature, but rebuild it from big angled slabs with moss on top. Use it as the gate to the Travel Boat dock.
- **Travel Boat:** Small sailboat with a green sail moored at a second pier.

## Trees and plants
- Stylized pines in 3 sizes (keep pines, they work) PLUS round oak trees for variety near the village.
- Clumps of 3 to 7 trees with clear gaps. Fewer trees along the main path so it reads.
- Bushes: round 3-part bushes with a few red berries, in clusters.

## Shallow Reef Ring
Classic coral reef, matching the target image 1:1. This is the showcase.

## Lighting preset
- ClockTime 14, `Ambient #7A86A8`, `OutdoorAmbient #9AA6C8`
- Atmosphere color `#C7DFFF`, decay `#9FC4FF`
- ColorCorrection tint `#FFFFFF`, saturation 0.15
- Water color `#2E9BE6`

## Upgrade tiers
- **Tier 1:** Short pier, market and spear shop are simple stalls, plaza is dirt with a small well.
- **Tier 2:** T-shaped pier, shops become cottages, stone plaza, fountain, lanterns along path.
- **Tier 3:** Second fishing platform, flags and bunting across the plaza, lighthouse lit with rotating beam, flower boxes everywhere near buildings.

## Do NOT
- Do not scatter single green or gray blocks on the grass.
- Do not use per-block random grass tones.
- Do not make every tree the same pine.


---
---

# MAP 2: DesertCoast (DESERT, 2nd island, origin 1300,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **DesertCoast** (see `references/03`, `04`, `05` and `references/current_generation/DesertCoast/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 3). Keep the Model name `DesertCoast`. Keep the layout idea (long pier into the center, village plaza in the middle, mesas around the edge, temple arch top left, waterfall mesa top center) but rebuild everything to the style bible. This island has the WORST clutter problem: remove every loose brick on the sand and plateaus.

---

## Mood
Sun-baked oasis trading town on red rock mesas. Warm, bright, bustling market energy.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: sand | Light sand | `#F2DDAE` |
| Sand patch variation | Warm sand | `#E8C98A` |
| Secondary: mesa rock | Terracotta | `#C8654A` |
| Rock dark band | Rust | `#9E4A3A` |
| Rock light band | Peach | `#E89C78` |
| Adobe walls | Clay | `#E3A46F` |
| Adobe trim | Dark clay | `#B87447` |
| Wood | Tan / brown | `#C08A55` / `#7A4E2D` |
| Oasis water | Turquoise | `#3EC6D9` |
| Accents (props only) | Turquoise, red, yellow, cactus green | `#3EC6D9` `#F2484B` `#FFD23F` `#3FAE4A` |

## Terrain
- 3 tiers: wide sand beach, main sandy plateau with the town, tall mesas around the edge.
- **Mesas:** the big change. Rebuild as large flat-topped terracotta slabs stacked in clear horizontal strata bands (light / mid / dark), with slight tilts and overhanging lips. Tops are sand-colored caps. Reference: real Monument Valley strata, but chunky and toy-like.
- Sand: 2 tones in big dune-shaped patches. NO scattered tiny bricks, pebbles, or cubes.
- Beach rocks: replace all the small red/white rock lumps with **3 hero rock arches or hoodoos** on the beach.
- **Oasis:** small turquoise pool near the plaza with palms and reeds around it (replaces the random blue part).
- Waterfall: keep the waterfall mesa, make the fall wider (6+ studs) and land in a turquoise pool.

## Landmark
**Sun Temple on the tallest mesa (top left).** Big stepped temple with a giant arch and a golden sun disc on top (Neon gold + light). Wide carved staircase with torches leading up. Visible from the end of the pier.

## Zones (themed)
- **Main Dock:** Long sun-bleached wooden pier with a wide T end (current pier is a good start). Add rope railings, clay pots, spear rack, a shade canopy (striped cloth) at the end, lanterns. Rowboat tied to the side. Under the water: coral reef with warmer corals (orange, red, yellow) and sand-colored rock mixed with periwinkle.
- **Hub Plaza:** Tiled sandstone plaza (2 tones in a simple pattern, not random). Centerpiece: stone well with a turquoise water top and a little roof. Palm planters at the corners.
- **Fish Market:** Bazaar stall row: 3 stalls with striped awnings (red/yellow/turquoise), baskets of fish, clay jars, hanging fish, rug on the ground.
- **Spear Shop:** 2-story adobe building with rounded corners, wooden beams poking out of the walls (vigas), a balcony, spears displayed on the wall, big spear sign.
- **Upgrade Station:** Mud-brick workshop with scaffolding, stacked clay bricks, a camel-cart of supplies.
- **Travel Boat:** Small dhow-style boat with a triangular cream sail at a second pier.

## Building fixes (from reference 05)
The current adobe houses are flat boxes. Fix:
- Rounded or beveled corners, slightly tapered walls.
- Darker clay plinth at the base, lighter trim band at the roofline.
- Recessed windows with wooden frames and turquoise shutters.
- Viga beams sticking out under the roofline.
- Rooftop details: water jar, small dome, or rooftop canopy.
- Doors with frames, steps, and a pot cluster beside them.
- Scale all lanterns, tables, and the well up to player size (style bible 5.4).

## Trees and plants
- Stylized palms in 3 sizes: segmented curved trunk (3 to 5 tilted segments), 5 to 7 big clean leaf fronds. No voxel smears.
- Cacti: saguaro style in 2 to 3 sizes, clustered with a rock or near a building, never alone in open sand.
- Desert shrubs and dry grass tufts only at rock bases and path edges.

## Shallow Reef Ring
Warm coral reef: orange, red, and yellow tube corals, sand shelves, a few clam shells and a sunken clay pot cluster.

## Lighting preset
- ClockTime 15, `Ambient #A08070`, `OutdoorAmbient #C8A890`
- Atmosphere color `#FFE2B8`, decay `#FFC98A`, Haze 1.5
- ColorCorrection tint `#FFF4E6`, saturation 0.2
- Water color `#2DB8E0`

## Upgrade tiers
- **Tier 1:** Short pier, one bazaar stall, spear shop is a tent, plaza is plain sand with a small well.
- **Tier 2:** T pier with canopy, 3 bazaar stalls, adobe spear shop, tiled plaza, oasis pool.
- **Tier 3:** Second pier platform, banners strung across the plaza, Sun Temple disc glows, extra palms and lanterns.

## Do NOT
- Do not leave a single loose brick on the sand. Search and delete.
- Do not dot red rocks randomly across the beach.
- Do not mix stud sizes (reference 05 has huge studs next to tiny studs).


---
---

# MAP 3: FrostCoast (SNOW, 3rd island, origin 2600,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **FrostCoast** (see `references/current_generation/FrostCoast/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 4). Keep the good ideas (log cabin village, campfire, snowmen, frozen pond, frozen waterfall, icebergs) but rebuild everything to the style bible using the shared layout (section 4). Keep the Model name `FrostCoast`.

---

## Mood
Arctic fishing outpost. Crisp, cold, cozy lights against snow. Northern-village feel with ice fishing vibes.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: snow | Snow white (slightly blue) | `#F4F8FF` |
| Snow shadow patch | Pale blue | `#D6E4F5` |
| Secondary: rock | Slate lavender | `#7C86C9` |
| Rock dark band | Deep slate | `#565FA3` |
| Ice | Ice blue | `#9FD8F2` |
| Deep ice | Glacier blue | `#5BB6E3` |
| Wood | Red-brown / dark | `#8A4B32` / `#5A3222` |
| Pine foliage | Dark teal green | `#2F7A5E` |
| Accents (props only) | Warm orange, red, gold, cyan | `#FF8A3D` `#E8403A` `#FFC93C` `#3FE0F0` |

Warm accents (lanterns, cabin windows, red roofs) are what make snow maps look alive. Use them on every building.

## Terrain
- 3 tiers: icy shore shelf, main snowy plateau, tall glacier peak.
- Cliffs: big slate-lavender slabs with thick **snow caps** that overhang the edge by 1 to 2 studs, and a few ice-blue icicle clusters hanging under the overhangs.
- Snow ground: 2 tones in soft drifts, with snow mounds piled against building walls and rocks.
- Shoreline: flat ice sheets broken into large plates stepping into the water, with a few floating ice chunks (big, 6+ studs, not tiny).
- Frozen pond near the plaza with an ice-fishing hole and a little bench.
- Replace beach rock clutter with **3 hero ice formations**: angled glacier shards (ice blue with white tops).

## Landmark
**Glacier Peak with an Ice Crystal.** Tall angled glacier spire on the highest tier with a giant glowing cyan crystal at the top (Neon + PointLight, light bloom). Switchback path with lanterns and a wooden bridge over a crevasse leads up.

## Zones (themed)
- **Main Dock:** Heavy timber pier with snow on the planks and railings, ice-crusted posts, warm lanterns, a fire barrel, spear rack, fish crates. End platform has an ice-fishing-style hole cut in an adjacent ice sheet as decoration. Under the water: icy reef (see below).
- **Hub Plaza:** Cleared stone plaza with a big campfire ring in the center, logs as benches, a snowman, a carved fish totem pole.
- **Fish Market:** Log cabin stall with a red roof under snow, ice blocks holding fish, hanging dried fish, lantern-lit sign.
- **Spear Shop:** Two-story A-frame cabin, steep red roof with snow, chimney with smoke particles, warm orange windows, harpoons on a wall rack outside.
- **Upgrade Station:** Lumber camp: sled stacked with logs, axe in a stump, workshop shed, blueprint board.
- **Travel Boat:** Small icebreaker boat with a red hull at a second pier.

## Trees and plants
- Snowy pines in 3 sizes: dark teal tiers with white snow on the top of each tier.
- Dead/bare trees (thin, 2 to 3 branches) in a few spots for contrast.
- Snow-covered bushes and frosty grass tufts at rock bases.
- Clumps of 3 to 7 pines, gaps between clumps.

## Shallow Reef Ring
Cold-water reef: slate rock shelves with ice-blue crystals, kelp forests (tall dark green and teal kelp), white and pale pink anemones, starfish, a few sea urchin clusters (purple). Keep the chunky coral-reef shapes from the target, just recolored cold.

## Lighting preset
- ClockTime 16.5 (low golden-cold sun), `Ambient #7880A8`, `OutdoorAmbient #A8B4D8`
- Atmosphere color `#DCE8FF`, decay `#A8C0F0`, Density 0.3
- ColorCorrection tint `#F0F6FF`, saturation 0.1
- Water color `#3A8FC9`
- Optional: light snowfall particle emitter around the player (low rate).

## Upgrade tiers
- **Tier 1:** Short pier, market is a tent with ice blocks, small campfire, no lanterns.
- **Tier 2:** Full timber pier, log cabins, plaza with totem and campfire ring, lanterns along path.
- **Tier 3:** Second platform, string lights between cabins, crystal on the peak glows and pulses, aurora effect in the sky (optional skybox swap).

## Do NOT
- Do not make the map all white. Snow needs blue shadow tones, warm lights, and red roofs for contrast.
- Do not scatter small ice cubes or snow blocks around.
- Do not use gray for rock; use the slate lavender so it matches the reef style.


---
---

# MAP 4: VolcanicIsland (VOLCANO, final island, origin 3900,0,0)

Follow `00_STYLE_BIBLE.md` for all rules. This file only adds what is specific to this island.

**Task:** REBUILD the existing **VolcanicIsland** (see `references/current_generation/VolcanicIsland/`; problems listed in `01_CURRENT_GENERATION_PROBLEMS.md` section 5). Keep the good ideas (crater lava pool, lava falls, basalt columns as a few hero clusters, braziers, stilt-hut village) but rebuild everything to the style bible using the shared layout (section 4). Remove the pine trees. Keep the Model name `VolcanicIsland`.

---

## Mood
Dramatic end-game island. Dark rock, glowing lava, warm orange light. Dangerous but still toy-like and colorful, not grim. Think stylized cartoon volcano, not realistic.

## Palette
| Role | Color | Hex |
|---|---|---|
| Dominant: basalt rock | Purple-black | `#3A3346` |
| Rock mid band | Dusty purple | `#57496B` |
| Rock light band / ash ground | Ash mauve | `#7A6C85` |
| Black sand beach | Charcoal | `#2E2A33` |
| Lava (Neon material) | Hot orange / yellow core | `#FF5A1F` / `#FFB01F` |
| Cooling lava crust | Deep red | `#B5301E` |
| Wood (charred) | Dark brown | `#4A2E22` |
| Accents (props only) | Teal crystals, sulfur yellow, red banners | `#33E0C0` `#F2D43A` `#E83A3A` |

Keep the rock purple-tinted so it fits the periwinkle family of the reef target, just much darker. The teal crystals are the cool accent that balances all the orange.

## Terrain
- 3 tiers: black sand beach, main plateau with the village (built on cooled lava rock), and the volcano cone.
- Cliffs: big angled basalt slabs, with a few **hexagonal basalt column clusters** (like Giant's Causeway) as hero features at the shore.
- **Lava rivers:** 2 lava channels flowing from the volcano down to the sea, built from Neon parts with a darker crust edge on each side. Where lava meets the ocean, add a steam particle cloud and a rock arch.
- Ash ground: 2 tones in large patches, plus small glowing cracks (thin Neon orange lines) only in a few deliberate spots.
- Teal crystal clusters (3 to 5 crystals each) at cliff bases and cave mouths.
- Wooden or stone bridges cross the lava rivers on the main path.

## Landmark
**The Volcano.** Huge stepped cone made of angled slabs (not a smooth mesh), glowing lava pool in the crater, lava light bloom, smoke particles rising. Visible from everywhere. Optional: a small obsidian shrine on the crater rim with a giant teal crystal.

## Zones (themed)
- **Main Dock:** Stone-and-charred-wood pier with metal braziers (fire particles), a big spear rack, heat-proof fish crates, red banners. Under the water: volcanic reef (see below).
- **Hub Plaza:** Obsidian-tiled plaza (2 tones in a pattern), centerpiece is a lava fountain: a stone bowl with a glowing Neon lava pool and a fish statue.
- **Fish Market:** Stone stall built into the rock with a red cloth awning, fish on cooling rocks, hanging lanterns.
- **Spear Shop:** Blacksmith forge: stone building with a big chimney, glowing furnace, anvil, spears cooling in a rack, sparks particles.
- **Upgrade Station:** Obsidian quarry: cut stone blocks, a crane made of wood and rope, minecart with crystals.
- **Travel Boat:** Armored boat with an iron hull at a second pier (final island, so this can travel back to earlier islands).

## Trees and plants
- Charred dead trees (black trunks, a few branches) in clumps.
- A few hardy palms with orange-tinted fronds near the beach for color.
- Glowing mushrooms (teal caps) and fire flowers (orange) in small clusters at rock bases.

## Shallow Reef Ring
Volcanic reef: dark basalt shelves, glowing hydrothermal vents (Neon orange cracks with bubble particles), teal and purple tube corals, red anemones, crystal clusters. Same chunky shelf shapes as the target, just dark rock with glowing accents.

## Lighting preset
- ClockTime 18.5 (sunset), `Ambient #6A4050`, `OutdoorAmbient #8A5060`
- Atmosphere color `#FF9A6A`, decay `#6A3A5A`, Density 0.35, Haze 2
- ColorCorrection tint `#FFE8DC`, saturation 0.2, contrast 0.1
- Bloom intensity 0.6 (lava glow)
- Water color `#1F6E9E` (darker)
- Optional: ash particles floating in the air (very low rate).

## Upgrade tiers
- **Tier 1:** Short stone pier, market is a cloth tent, forge is a single anvil and fire pit, plaza is bare ash ground.
- **Tier 2:** Full pier with braziers, stone buildings, obsidian plaza, lava fountain, bridges over lava.
- **Tier 3:** Second fishing platform, red banners everywhere, crater shrine crystal glows, extra lava falls, teal crystal lanterns along the path.

## Do NOT
- Do not make it all black and orange. Use the purple rock bands and teal accents.
- Do not cover the ground in glowing cracks; keep them rare and deliberate.
- Do not build the volcano as one smooth gray cone. Use stacked angled slabs with strata bands.
- Do not place lava where players walk without a clear bridge or barrier.
